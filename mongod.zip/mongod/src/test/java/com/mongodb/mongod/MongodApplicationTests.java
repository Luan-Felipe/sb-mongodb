package com.mongodb.mongod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodApplicationTests {

	@Test
	void contextLoads() {
	}

}
