package com.mongodb.mongod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongodApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongodApplication.class, args);
	}

}
